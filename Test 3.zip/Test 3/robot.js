function moveLeft() {
	
	var robot = document.querySelector("img");
	var isAnimating = startAnimating();
	var endOfScreen = window.innerWidth;
	var pos = 0, lastTime = null;
	if (isAnimating) {
		requestAnimationFrame(animate);
	}
	else {
		cancelAnimationFrame(id);
	}
	function animate(time) {
		if (lastTime != null) {
			pos += (time - lastTime) * 0.001;
		}
		lastTime = time;
		robot.style.left = (pos * 200) + "px";
		id = requestAnimationFrame(animate);
	}
	
}


function startAnimating() {
	
	var button = document.getElementById("moveLeft");
	var runAnimation;
	if (button.innerHTML == "Start") {
		button.innerHTML = "Stop";
		runAnimation = true;
		
	}

	else{
		button.innerHTML = "Start";
		runAnimation = false;
	}
	 return runAnimation
	
	
}